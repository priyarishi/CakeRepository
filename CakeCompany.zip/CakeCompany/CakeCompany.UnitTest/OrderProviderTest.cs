﻿
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CakeCompany.Provider;
using CakeCompany.Models;
using System;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace CakeCompany.UnitTest
{
    [TestClass]     
    public class OrderProviderTest
    {
        List<Order> cancelledOrders = new List<Order>();
        List<IProduct> products = new List<IProduct>();

        [TestMethod]
        
        public void OrdersToProcessWhenZeroLatestOrders()
        {
            var orderProviderMock = new Mock<IOrderProvider>();
            var loggerMock = new Mock<ILogger>();
            var cakeMock = new Mock<ICakeProvider>();
            var paymentMock = new Mock<IPaymentProvider>();
            Order[] result = { };
            orderProviderMock.Setup(p => p.GetLatestOrders()).Returns(result);
            paymentMock.Setup(p => p.Process(new("NormalCake", DateTime.Now.AddHours(4), 1, Cake.RedVelvet, 120.25))).Returns(new PaymentIn { HasCreditLimit = true, IsSuccessful = true });

            OrderProvider orderProvider = new OrderProvider(loggerMock.Object, cakeMock.Object, paymentMock.Object);
            products = orderProvider.GetOrdersToProcess(cancelledOrders);
            Assert.AreEqual(products.Count, 0);
                
          }

        [TestMethod]

        public void OrdersToProcessWhenBakingTimeExceedsDelivery()
        {
            var orderProviderMock = new Mock<IOrderProvider>();
            var loggerMock = new Mock<ILogger>();
            var cakeMock = new Mock<ICakeProvider>();
            var paymentMock = new Mock<IPaymentProvider>();

          
            Order[] result = { new("NormalCake", DateTime.Now.AddHours(4), 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25) };

            cakeMock.Setup(p => p.Check(result[0])).Returns(DateTime.Now.AddHours(4));
            paymentMock.Setup(p => p.Process(result[0])).Returns(new PaymentIn { HasCreditLimit = true, IsSuccessful = true });

            orderProviderMock.Setup(p => p.GetLatestOrders()).Returns(result);
            
            OrderProvider orderProvider = new OrderProvider(loggerMock.Object, cakeMock.Object, paymentMock.Object);
         
            products = orderProvider.GetOrdersToProcess(cancelledOrders);
            Assert.AreEqual(cancelledOrders.Count, 0);

        }




    }

}
