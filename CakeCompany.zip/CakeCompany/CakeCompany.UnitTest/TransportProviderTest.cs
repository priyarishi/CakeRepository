﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CakeCompany.UnitTest
{
    [TestClass]
    public class TransportProviderTest
    {
        List<Order> cancelledOrders = new List<Order>();
        List<IProduct> products = new List<IProduct>();

        [TestMethod]
        public void ValidateVanQuantity()
        {
           
            var loggerMock = new Mock<ILogger<ITransportProvider>>();          
            products.Add(new Product { Cake = Cake.RedVelvet, Id = System.Guid.NewGuid(), Quantity = 500, OrderId = 1 });

            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            string response = transportProvider.CheckForAvailability(products);
            Assert.AreEqual(response, "Van");

        }

        [TestMethod]
        public void ValidateTruckQuantity()
        {

            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            products.Add(new Product { Cake = Cake.RedVelvet, Id = System.Guid.NewGuid(), Quantity = 2000, OrderId = 1 });

            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            string response = transportProvider.CheckForAvailability(products);
            Assert.AreEqual(response, "Truck");

        }


        [TestMethod]
        public void ValidateShipQuantity()
        {

            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            products.Add(new Product { Cake = Cake.RedVelvet, Id = System.Guid.NewGuid(), Quantity = 6000, OrderId = 1 });

            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            string response = transportProvider.CheckForAvailability(products);
            Assert.AreEqual(response, "Ship");

        }

        [TestMethod]
        public void ValidateTransportModeVan()
        {
            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            ITransport? response = transportProvider.GetTransportMode("Van");

            Assert.IsInstanceOfType(response, typeof(Van));
        }

        [TestMethod]
        public void ValidateTransportModeTruck()
        {
            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            ITransport? response = transportProvider.GetTransportMode("Truck");

            Assert.IsInstanceOfType(response, typeof(Truck));
        }

        [TestMethod]
        public void ValidateTransportModeShip()
        {
            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            ITransport? response = transportProvider.GetTransportMode("Ship");
            Assert.IsInstanceOfType(response, typeof(Ship));
        }

        [TestMethod]
        public void DeliverProductShip()
        {
            var loggerMock = new Mock<ILogger<ITransportProvider>>();
            products.Add(new Product { Cake = Cake.RedVelvet, Id = System.Guid.NewGuid(), Quantity = 6000, OrderId = 1 });

            TransportProvider transportProvider = new TransportProvider(loggerMock.Object);
            bool response = transportProvider.DeliverProduct(products);
            Assert.IsTrue(response);
        }
    }
}
