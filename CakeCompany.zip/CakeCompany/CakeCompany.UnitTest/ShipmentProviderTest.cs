﻿using CakeCompany.Models;
using CakeCompany.Provider;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

using System.Collections.Generic;


namespace CakeCompany.UnitTest
{
    [TestClass]
    public class ShipmentProviderTest
    {
        List<Order> cancelledOrders = new List<Order>();
        List<IProduct> products = new List<IProduct>();

        [TestMethod]

        public void ValidateGetShipmentWithNoProducts()
        {
            var orderProviderMock = new Mock<IOrderProvider>();
            var loggerMock = new Mock<ILogger<IShipmentProvider>>();
            var transportMock = new Mock<ITransportProvider>();
            var paymentMock = new Mock<IPaymentProvider>();
            Order[] result = { };
            orderProviderMock.Setup(p => p.GetOrdersToProcess(cancelledOrders)).Returns(products);


            ShipmentProvider shipmentProvider = new ShipmentProvider(loggerMock.Object, orderProviderMock.Object, transportMock.Object);
            bool response = shipmentProvider.GetShipment();
            Assert.IsFalse(response);

        }

        [TestMethod]
        public void ValidateGetShipmentWithProductCount()
        {
            var orderProviderMock = new Mock<IOrderProvider>();
            var loggerMock = new Mock<ILogger<IShipmentProvider>>();
            var transportMock = new Mock<ITransportProvider>();
            var paymentMock = new Mock<IPaymentProvider>();

            products.Add(new Product{ Cake = Cake.RedVelvet, Id = System.Guid.NewGuid(), Quantity = 2, OrderId = 1 });
            orderProviderMock.Setup(p => p.GetOrdersToProcess(cancelledOrders)).Returns(products);
            transportMock.Setup(p => p.DeliverProduct(products)).Returns(true);

            ShipmentProvider shipmentProvider = new ShipmentProvider(loggerMock.Object, orderProviderMock.Object, transportMock.Object);
            bool response = shipmentProvider.GetShipment();
            Assert.IsTrue(response);

        }
    }
}
