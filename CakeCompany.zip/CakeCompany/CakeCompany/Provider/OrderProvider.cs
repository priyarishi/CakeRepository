﻿using System.Reflection.Metadata.Ecma335;
using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider
{

    public class OrderProvider : IOrderProvider
    {
        ILogger logger;
        ICakeProvider cakeProvider;
        IPaymentProvider paymentProvider;
        ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
        {

        });

        public OrderProvider(ILogger _logger, ICakeProvider _cakeProvider, IPaymentProvider paymentProvider)
        {
            this.logger = _logger;
            this.cakeProvider = _cakeProvider;
            this.paymentProvider = paymentProvider;
        }
        public Order[] GetLatestOrders()
        {
            logger.LogInformation("Getting the Latest Orders");

            return new Order[]
            {
            new("CakeBox", DateTime.Now, 1, Cake.RedVelvet, 120.25),
            new("ImportantCakeShop", DateTime.Now, 1, Cake.RedVelvet, 120.25)
            };
        }
        public void UpdateOrders(Order[] orders)
        {
            logger.LogInformation("Updating Orders");
        }

        public List<IProduct> GetOrdersToProcess(List<Order> cancelledOrders)
        {
            List<IProduct> products = new List<IProduct>();
            try
            {
                IList<Order> orders = this.GetLatestOrders();
                if (!orders.Any())
                {
                    return products;
                }


                foreach (var order in orders)
                {
                    DateTime estimatedBakeTime = cakeProvider.Check(order);

                    if (estimatedBakeTime > order.EstimatedDeliveryTime)
                    {
                        cancelledOrders.Add(order);
                        return products;
                    }

                    if (!paymentProvider.Process(order).IsSuccessful)
                    {
                        cancelledOrders.Add(order);
                        return products;
                    }

                    IProduct product = this.cakeProvider.Bake(order);
                    products.Add(product);
                }
            }
            catch (Exception ex)
            {
                logger.LogError("The exception logged as :" + ex.Message.ToString());
            }
            return products;
        }
    }
}


