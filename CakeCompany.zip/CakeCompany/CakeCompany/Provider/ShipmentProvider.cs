﻿using CakeCompany.Models;
using CakeCompany.Models.Transport;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider
{
    public class ShipmentProvider : IShipmentProvider
    {
        ILogger<IShipmentProvider> logger;
        IOrderProvider orderProvider;
        ITransportProvider transportProvider;


        public ShipmentProvider(ILogger<IShipmentProvider> logger, IOrderProvider _orderProvider, ITransportProvider _transportProvider)
        {
            this.logger = logger;
            this.orderProvider = _orderProvider;
            this.transportProvider = _transportProvider;
        }

        public bool GetShipment()
        {
            logger.LogInformation("Shipping the product on request from the front end.");
            var cancelledOrders = new List<Order>();
            List<IProduct> products = orderProvider.GetOrdersToProcess(cancelledOrders);
            bool response = false;
            if (products.Any())
            {
                response = transportProvider.DeliverProduct(products);
            }

            return response;


        }
    }
}
