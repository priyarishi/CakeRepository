﻿using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;

public class PaymentProvider:IPaymentProvider
{
    ILogger<IPaymentProvider> logger;

    public PaymentProvider(ILogger<IPaymentProvider> logger)
    {
        this.logger = logger;
    }

    public PaymentIn Process(Order order)
    {
        logger.LogInformation("Processing the order payment");

        if (order.ClientName.Contains("Important"))
        {
            return new PaymentIn
            {
                HasCreditLimit = false,
                IsSuccessful = true
            };
        }

        return new PaymentIn
        {
            HasCreditLimit = true,
            IsSuccessful = true
        };
    }
}