﻿using CakeCompany.Models;
using Microsoft.Extensions.Logging;

namespace CakeCompany.Provider;

public class CakeProvider:ICakeProvider
{
    ILogger<ICakeProvider> logger;

    public CakeProvider(ILogger<ICakeProvider> _logger)
    {
        this.logger = _logger;
    }

    public DateTime Check(Order order)
    {
        logger.LogInformation("Returning the preparation times for specific cake types");

        if (order.Name == Cake.Chocolate)
        {
            return DateTime.Now.AddHours(2);
        }

        if (order.Name == Cake.RedVelvet)
        {
            return DateTime.Now.AddHours(3);
        }

        return DateTime.Now.AddHours(4);
    }

    public IProduct Bake(Order order)
    {
        logger.LogInformation("Returning the prepared Product");

       
            return new Product ()
            {
                Cake = order.Name,
                Id = new Guid(),
                Quantity = order.Quantity
            };
       
    }
}