﻿using CakeCompany.Models;
using Microsoft.VisualBasic;
using static System.Net.Mime.MediaTypeNames;
using System.Runtime.Intrinsics.X86;
using Microsoft.Extensions.Logging;
using CakeCompany.Models.Transport;

namespace CakeCompany.Provider;

public class TransportProvider:ITransportProvider
{
    ILogger<ITransportProvider> _logger;
    ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
    {

    });
    public TransportProvider(ILogger<ITransportProvider> logger)
    {
        _logger = logger;
    }

    public string CheckForAvailability(List<IProduct> products)
    {
        this._logger.LogInformation("Returning the relevant transport as per the quanity of the product to be sent.");

        if (products.Sum(p => p.Quantity) < 1000)
        {
            return "Van";
        }

        if (products.Sum(p => p.Quantity) > 1000 && products.Sum(p => p.Quantity) < 5000)
        {
            return "Truck";
        }

        return "Ship";
    }

    public ITransport? GetTransportMode(string transport)
    {      

        if(transport=="Van")
        {
            return new Van(loggerFactory.CreateLogger<ITransport>());
        }
        else if(transport=="Truck")
        {
            return new Truck(loggerFactory.CreateLogger<ITransport>());
        }
        else if (transport=="Ship")
        {
            return new  Ship(loggerFactory.CreateLogger<ITransport>());
        }

        return null;
    }

    public bool DeliverProduct(List<IProduct> products)
    {
        bool response = true;
        try
        {
            string transport = CheckForAvailability(products);
            ITransport? mode = GetTransportMode(transport);

            if (mode != null)
            {
               response= mode.Deliver(products);
            }
        }
        catch(Exception ex)
        {
            response = false;
            _logger.LogError("Error in delivering the product :" + ex.Message.ToString());
        }
        return response;
    }
}
