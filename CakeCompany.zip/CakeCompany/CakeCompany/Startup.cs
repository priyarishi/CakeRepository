﻿
using CakeCompany.Provider;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using ServiceStack;
using ServiceStack.Configuration;

public class Startup
{ 
    public void ConfigureServices(IServiceCollection services)
    {
        // configure logging
        services.AddLogging(builder =>
        {
            builder.AddConsole();
            builder.AddDebug();
        });

        // build config
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddEnvironmentVariables()
            .Build();

        // add service loggers
        services.Configure<AppSettings>(configuration.GetSection("App"));
        services.AddSingleton<ILogger, Logger<IShipmentProvider>>();
        services.AddSingleton<ILogger, Logger<ICakeProvider>>();
        services.AddSingleton<ILogger, Logger<IPaymentProvider>>();
        services.AddSingleton<ILogger, Logger<ITransportProvider>>();

        services.AddTransient<ICakeProvider, CakeProvider>();
        services.AddTransient<IPaymentProvider, PaymentProvider>();
        services.AddTransient<IOrderProvider, OrderProvider>();
        services.AddTransient<ITransportProvider, TransportProvider>();
        services.AddTransient<IShipmentProvider, ShipmentProvider>();

        // add app
        services.AddTransient<App>();
    }
}
