﻿namespace CakeCompany.Models.Cakes;

internal record Chocolate(string CakeName);