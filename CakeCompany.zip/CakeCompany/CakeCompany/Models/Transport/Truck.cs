﻿using Microsoft.Extensions.Logging;

namespace CakeCompany.Models.Transport;

public class Truck:ITransport
{
    ILogger<ITransport> logger;
    internal Truck(ILogger<ITransport> logger)
    {
        this.logger = logger;
    }
    public bool Deliver(List<IProduct> products)
    {
        logger.LogInformation("Deliver method for the Ship transport Mode Called");
        return true;
    }
}