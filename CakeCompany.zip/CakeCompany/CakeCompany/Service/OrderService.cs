﻿namespace CakeCompany.Service
{
    internal class OrderService
    {
    }
}