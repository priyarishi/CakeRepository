﻿// See https://aka.ms/new-console-template for more information

using CakeCompany.Provider;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;


IServiceCollection services = new ServiceCollection();
// create service collection
Startup startup = new Startup();
startup.ConfigureServices(services);

// create service provider
using var serviceProvider = services.BuildServiceProvider();
// entry to run app
#pragma warning disable CS8602 // Dereference of a possibly null reference.
serviceProvider.GetService<App>().Run(args);
#pragma warning restore CS8602 // Dereference of a possibly null reference.

public class App
{
    private readonly ILogger<App> _logger;
    public IOrderProvider _orderProvider;
    public ITransportProvider _trnsportProvider;
    public IShipmentProvider _shipmentProvider;
   public App( ILogger<App> logger, IOrderProvider orderProvider, ITransportProvider transportProvider, IShipmentProvider shipmentProvider)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _orderProvider = orderProvider;
        _trnsportProvider = transportProvider;
        _shipmentProvider = shipmentProvider;
    }

    public void Run(string[] args)
    {
        _logger.LogInformation("Starting...");

        _shipmentProvider.GetShipment();

        Console.WriteLine("Hiya world!");

        _logger.LogInformation("Finished!");
    }
}






